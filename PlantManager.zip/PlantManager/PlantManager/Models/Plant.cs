﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlantManager.Models
{
    public class Plant
    {
        public int PlantID { get; set; }
        public string Name { get; set; }
        public PlantStatusEnum PlantStatus { get; set; }
        public DateTime LastSession { get; set; }
        public bool IncludeInGroup { get; set; }

        public Plant()
        {
            Name = "Unknown";
            LastSession = DateTime.Now;
        }

    }
}
