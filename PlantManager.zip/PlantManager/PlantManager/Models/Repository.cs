﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PlantManager.Models
{
    public static class Repository
    {        
        private static List<Plant> plants = new List<Plant> {
            new Plant{PlantID =1, Name ="Plant1", PlantStatus = PlantStatusEnum.Alert, IncludeInGroup = false, LastSession = (DateTime.Now).AddHours(-6)},
            new Plant{PlantID =2, Name ="Plant2", PlantStatus = PlantStatusEnum.Alert, IncludeInGroup = false, LastSession = (DateTime.Now).AddHours(-6)},
            new Plant{PlantID =3, Name ="Plant3", PlantStatus = PlantStatusEnum.Alert, IncludeInGroup = false, LastSession = (DateTime.Now).AddHours(-6)},
            new Plant{PlantID =4, Name ="Plant4", PlantStatus = PlantStatusEnum.Alert, IncludeInGroup = false, LastSession = (DateTime.Now).AddHours(-6)},
            new Plant{PlantID =5, Name ="Plant5", PlantStatus = PlantStatusEnum.Alert, IncludeInGroup = false, LastSession = (DateTime.Now).AddHours(-6)}
        };

        public static void PlantUpdates()
        {

        } 

        public static IEnumerable<Plant> Plants
        {
            get
            {
                return plants;
            }
        }
    }
}


